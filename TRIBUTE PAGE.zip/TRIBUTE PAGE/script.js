// Typewriter effect for heading
const titleText = "Dr. A.P.J. Abdul Kalam";
let i = 0;
const speed = 100;
function typeWriter() {
  if (i < titleText.length) {
    document.getElementById("typewriter").innerHTML += titleText.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
typeWriter();

// Quote Rotator
const quotes = [
  "\"Dream, dream, dream. Dreams transform into thoughts and thoughts result in action.\"",
  "\"If you want to shine like a sun, first burn like a sun.\"",
  "\"Excellence happens not by accident. It is a process.\"",
  "\"Don’t take rest after your first victory because if you fail in second, more lips are waiting to say that your first victory was just luck.\"",
  "\"All of us do not have equal talent. But, all of us have an equal opportunity to develop our talents.\"",
  "\"Be more dedicated to making solid achievements than in running after swift but synthetic happiness.\""
];
let quoteIndex = 0;
function rotateQuote() {
  document.getElementById("quote").innerText = quotes[quoteIndex];
  quoteIndex = (quoteIndex + 1) % quotes.length;
}
rotateQuote();
setInterval(rotateQuote, 1500);

// Theme Toggle
const themeToggle = document.querySelector(".toggle-theme");
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light-mode");
});

// Scroll Reveal Animation
const sections = document.querySelectorAll('.content h2, .content p, .content ul, .timeline, blockquote');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('reveal');
    }
  });
}, {
  threshold: 0.1
});

sections.forEach(section => {
  observer.observe(section);
});
